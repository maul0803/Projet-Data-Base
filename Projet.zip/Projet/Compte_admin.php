<!--version du 16/04/2023-->
<!--Modification du 02/04/2023 par Côme QUINTYN:
-ajout du mise en page minimale
-->
<!--Modifications du 16/04/2023 par Romain GUENNEAU:
  -complétion de la mise en page
-->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon Compte</title>
    <link href="login.css" rel="stylesheet">
</head>
<?php include "header.php"; ?>
<body>
<?php
// Require('config.php');
// Initialiser la session
// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}
?>

<div class="come-success">
    <h1>Bienvenue <?php echo $_SESSION['email']; ?>!</h1>
    <h1>Votre statut est <?php echo $_SESSION['profile']; ?>!</h1>
    <p><font color="red">Vous vous êtes connecté avec succès.</font></p>
    <a href="logout.php"><font color="red">Déconnexion</font></a>

    <br>

    <a href="supprCompte.php"><font color="red" size="3pt"><u>Supprimer mon compte</u></font></a>
    <br>
    <a href="admin_book.php"><font color="black" size="3pt"><u>Book</u></font></a>

</div>
</body>


<?php include "footer.html"; ?>
</body>

<script>
    function Books() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("books").innerHTML = this.responseText;
        }
        };
        xmlhttp.open("GET", "books_admin.php", true);
        xmlhttp.send();
    }

    function fonctionCom(val) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("com").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "comUser.php?idr=" + val, true);
        xmlhttp.send();
    }

    function Username() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("username").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "changeUsername.php", true);
        xmlhttp.send();
    }
</script>
</html>
