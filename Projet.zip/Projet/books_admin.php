<?php
  session_start();

  $DB_USERNAME = $_SESSION['DB_USERNAME'];
  $DB_PASSWORD = $_SESSION['DB_PASSWORD'];
  $DB_SERVER = $_SESSION['DB_SERVER'];
  $DB_NAME = $_SESSION['DB_NAME'];

  $conn = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
  if($conn === false){
    die("ERREUR : Impossible de se connecter. " . mysqli_connect_error());
  }

  $query = "SELECT idBook,Title, Language_, Number_Of_Pages, Year_Of_Production, Subject, rack_number FROM project.Book";
  $result = mysqli_query($conn, $query);

  echo "<h2>Title</h2>";
  echo "<p></p>";
  echo "
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Language</th>
          <th>Pages</th>
          <th>Year</th>
          <th>Subject</th>
          <th>rack_number</th>
          <th>Action</th>
        </tr>
      </thead>
  ";

  while($rowData = mysqli_fetch_assoc($result)){
      $idBook = $rowData['idBook'];
      $Title = $rowData['Title'];
      $Language_ = $rowData['Language_'];
      $Number_Of_Pages = $rowData['Number_Of_Pages'];
      $Year_Of_Production = $rowData['Year_Of_Production'];
      $Subject = $rowData['Subject'];
      $rack_number = $rowData['rack_number'];

      echo "
        <tr>
          <td>
            <form method='POST' action='books_modification_admin.php?idBook=".$idBook."'>
              <input type='text' name='idBook' value='$idBook'>
              <input type='text' name='Title' value='$Title'>
              <input type='text' name='Language' value='$Language_'>
              <input type='text' name='Number_Of_Pages' value='$Number_Of_Pages'>
              <input type='text' name='Year_Of_Production' value='$Year_Of_Production'>
              <input type='text' name='Subject' value='$Subject'>
              <input type='text' name='Rack_number' value='$rack_number'>
              <input type='submit' value='modifier'>
            </form>
          </td>
        </tr>
      ";
  }

  echo "
      </tbody>
    </table>
  ";
?>
