<?php
session_start();
$DB_USERNAME = $_SESSION['DB_USERNAME'];
$DB_PASSWORD = $_SESSION['DB_PASSWORD'];
$DB_SERVER = $_SESSION['DB_SERVER'];
$DB_NAME = $_SESSION['DB_NAME'];

$conn = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);
if ($conn === false) {
    die("ERREUR : Impossible de se connecter. " . mysqli_connect_error());
}
?>
<?php
if (isset($_POST['idBook'])) {
    $idBook = $_GET['idBook'];
    $Language_ = $_POST['Language'];
    $Title = $_POST['Title'];
    $Number_Of_Pages = $_POST['Number_Of_Pages'];
    $Year_Of_Production = $_POST['Year_Of_Production'];
    $Subject = $_POST['Subject'];
    $Rack_number = $_POST['Rack_number'];

    $query = "UPDATE project.Book 
    SET Title = '$Title',
    Language_ = '$Language_', 
    Number_Of_Pages = '$Number_Of_Pages',
    Year_Of_Production = '$Year_Of_Production',
    Subject = '$Subject',
    rack_number = '$Rack_number'
    WHERE idBook = '$idBook'";
    $result = mysqli_query($conn, $query);

    if ($result) {
            header("Location: Compte_admin.php");
    }else {
            echo "Erreur lors de la mise à jour : " . mysqli_error($conn);
        }
}else {
    header("Location: Compte_admin.php");
}
?>
